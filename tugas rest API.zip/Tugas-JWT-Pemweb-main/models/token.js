const koneksi = require('../config/database');

const TokenModel = {
    saveToken: (token, userId, expires) => {
        const query = 'INSERT INTO tokens (token, user_id, expires_at, is_revoked) VALUES (?, ?, ?, ?)';
        return new Promise((resolve, reject) => {
            koneksi.query(query, [token, userId, expires, false], (err, result) => {
                if (err) reject(err);
                resolve(result);
            });
        });
    },

    revokeToken: (token) => {
        const query = 'UPDATE tokens SET is_revoked = true WHERE token = ?';
        return new Promise((resolve, reject) => {
            koneksi.query(query, [token], (err, result) => {
                if (err) reject(err);
                resolve(result);
            });
        });
    },

    isTokenValid: (token) => {
        const query = 'SELECT * FROM tokens WHERE token = ? AND is_revoked = false AND expires_at > NOW()';
        return new Promise((resolve, reject) => {
            koneksi.query(query, [token], (err, result) => {
                if (err) reject(err);
                resolve(result.length > 0);
            });
        });
    }
};

module.exports = TokenModel;
