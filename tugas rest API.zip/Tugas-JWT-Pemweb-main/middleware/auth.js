const jwt = require('jsonwebtoken');
const TokenModel = require('../models/token');
const rateLimit = require('express-rate-limit');

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 menit
    max: 100 // maksimal 100 request per IP
});

// Secret key untuk JWT
const JWT_SECRET = 'your-secret-key';

const auth = async (req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '');
        const decoded = jwt.verify(token, JWT_SECRET);
        
        // Cek apakah token masih valid
        const isValid = await TokenModel.isTokenValid(token);
        if (!isValid) {
            throw new Error('Token tidak valid');
        }

        // Simpan data user ke request
        req.user = decoded;
        req.token = token;

        // Catat akses
        const logQuery = 'INSERT INTO access_logs (user_id, endpoint, accessed_at) VALUES (?, ?, NOW())';
        koneksi.query(logQuery, [decoded.id, req.originalUrl]);

        next();
    } catch (error) {
        res.status(401).json({ error: 'Harap autentikasi.' });
    }
};

module.exports = { auth, limiter, JWT_SECRET };
