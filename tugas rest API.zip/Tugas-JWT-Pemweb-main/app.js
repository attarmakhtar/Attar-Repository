const express = require('express');
const bodyParser = require('body-parser');
const koneksi = require ('./config/database');
const app = express ();
const PORT = process.env.PORT || 3000;
const { auth, limiter, JWT_SECRET } = require('./middleware/auth');
const TokenModel = require('./models/token');
const moment = require('moment');
const jwt = require('jsonwebtoken');

//set body parser
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

// Login endpoint
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        // Cek kredensial di database (sesuaikan dengan struktur tabel user Anda)
        const query = 'SELECT * FROM users WHERE username = ? AND password = ?';
        koneksi.query(query, [username, password], async (err, rows) => {
            if (err) {
                return res.status(500).json({ error: err.message });
            }

            if (rows.length === 0) {
                return res.status(401).json({ error: 'Username atau password salah' });
            }

            const user = rows[0];
            const expires = moment().add(1, 'days').format('YYYY-MM-DD HH:mm:ss');
            
            // Buat token
            const token = jwt.sign({ id: user.id, username: user.username }, JWT_SECRET);
            
            // Simpan token
            await TokenModel.saveToken(token, user.id, expires);

            res.json({ token, expires });
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Logout endpoint
app.post('/api/logout', auth, async (req, res) => {
    try {
        await TokenModel.revokeToken(req.token);
        res.json({ message: 'Berhasil logout' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Terapkan middleware auth dan rate limit ke semua endpoint API
app.use('/api/latihanrestapi', [limiter, auth]);

app.post('/api/latihanrestapi', (req, res) => {
    //buat variabel penampung data dan querry sql
    const data = {...req.body};
    const querySql = 'INSERT INTO latihanrestapi SET ?';

    // jalankan querry 
    koneksi.query(querySql, data, (err, rows, field) => {
        // error handling
        if (err) {
            return res.status(500).json({message: 'Gagal insert data!', error:err});
        }

        // jika request berhasil
        res.status(201).json ({ succes: true, message: 'Berhasil Insert Data!'});
    });
});

// update data
app.put('/api/latihanrestapi/:id', (req, res) => {
    // buat variabel penampung data dan query sql
    const data = { ...req.body };
    const querySearch = 'SELECT * FROM latihanrestapi WHERE id = ?';
    const queryUpdate = 'UPDATE latihanrestapi SET ? WHERE id = ?';

    // jalankan query untuk melakukan pencarian data
    koneksi.query(querySearch, req.params.id, (err, rows, field) => {
        // error handling
        if (err) {
            return res.status(500).json({ message: 'Ada kesalahan', error: err });
        }

        // jika id yang dimasukkan sesuai dengan data yang ada di db
        if (rows.length) {
            // jalankan query update
            koneksi.query(queryUpdate, [data, req.params.id], (err, rows, field) => {
                // error handling
                if (err) {
                    return res.status(500).json({ message: 'Ada kesalahan', error: err });
                }
                // jika update berhasil
                res.status(200).json({ success: true, message: 'Berhasil update data!' });
            });
        } else {
            return res.status(404).json({ message: 'Data tidak ditemukan!', success: false });
        }
    });
});

// delete data
app.delete('/api/latihanrestapi/:id', (req, res) => {
    // buat query sql untuk mencari data dan hapus
    const querySearch = 'SELECT * FROM latihanrestapi WHERE id = ?';
    const queryDelete = 'DELETE FROM latihanrestapi WHERE id = ?';

    // jalankan query untuk melakukan pencarian data
    koneksi.query(querySearch, req.params.id, (err, rows, field) => {
        // error handling
        if (err) {
            return res.status(500).json({ message: 'Ada kesalahan', error: err });
        }

        // jika id yang dimasukkan sesuai dengan data yang ada di db
        if (rows.length) {
            // jalankan query delete
            koneksi.query(queryDelete, req.params.id, (err, rows, field) => {
                // error handling
                if (err) {
                    return res.status(500).json({ message: 'Ada kesalahan', error: err });
                }
                // jika delete berhasil
                res.status(200).json({ success: true, message: 'Berhasil hapus data!' });
            });
        } else {
            return res.status(404).json({ message: 'Data tidak ditemukan!', success: false });
        }
    });
});

// Tambahkan endpoint GET untuk membaca data
app.get('/api/latihanrestapi', (req, res) => {
    // buat query sql
    const querySql = 'SELECT * FROM latihanrestapi';

    // jalankan query
    koneksi.query(querySql, (err, rows, field) => {
        // error handling
        if (err) {
            return res.status(500).json({ message: 'Ada kesalahan', error: err });
        }

        // jika request berhasil
        res.status(200).json({ success: true, data: rows });
    });
});

//buat servernya
app.listen(PORT, () => console.log('Server Running at port: $ {PORT}'));

