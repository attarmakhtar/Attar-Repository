const express = require('express');
const router = express.Router();
const db = require('../config/db');  // Pastikan path ini benar

// Halaman untuk melihat hasil tangkapan ikan
router.get('/hasiltangkap', (req, res) => {
    const query = "SELECT h.*, n.nama FROM hasil_tangkapan_ikan h JOIN data_nelayan n ON h.id_nelayan = n.id";
    
    let filters = '';
    if (req.query.id_nelayan) {
        filters = " WHERE h.id_nelayan = ?";
    }

    db.query(query + filters, [req.query.id_nelayan], (err, result) => {
        if (err) throw err;

        // Ambil data nelayan untuk pilihan filter
        db.query('SELECT * FROM data_nelayan', (err, nelayanResult) => {
            if (err) throw err;

            res.render('hasiltangkap', {
                hasilTangkapan: result,
                nelayan: nelayanResult
            });
        });
    });
});

module.exports = router;
